//mod_amf.c is module for Apache httpd web server for detect mobile devices
//Copyright (C) 2009-2010-2011-2012-2013-2014  Idel Fuschini
//
//This program is free software: you can redistribute it and/or modify
//it under the terms of the GNU Affero General Public License as
//published by the Free Software Foundation, either version 3 of the
//License, or (at your option) any later version.
//
//Organizations that intend to use this file in it commercially
//or under different licensing terms should contact ApacheMobileFilter
//(http://www.apachemobilefilter.org/contacts/) to learn about licensing options for AMF.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU Affero General Public License for more details.
//
//You should have received a copy of the GNU Affero General Public License
//along with this program.  If not, see <http://www.gnu.org/licenses/>.



#include "mod_amf.h"
#include <ctype.h>
#include <fcntl.h>
#include <httpd.h>
#include <http_config.h>
#include <http_log.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string.h>

#include <netinet/tcp.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>
#include "apr_env.h"
#include "apr_pools.h"

#define BUFFER_SIZE 1024
#define MAX_SIZE 10000
#define MAX_ERROR_MSG 0x1000
#define AMF_VERSION "1.2.2"

#define AMF_HOST "cznic.dl.sourceforge.net"

#define ISMOBILE_URL "GET /project/mobilefilter/AMFPlusRepository/litemobiledetectionPlus.config \x0D\x0A\n\x0D\x0A\n"
#define ISTABLET_URL "GET /project/mobilefilter/AMFPlusRepository/litetabletdetectionPlus.config \x0D\x0A\n\x0D\x0A\n"
#define ISTOUCH_URL  "GET /project/mobilefilter/AMFPlusRepository/litetouchdetectionPlus.config \x0D\x0A\n\x0D\x0A\n"

int setFullBrowser=0;
int setDownloadParam=1;
int first=0;
int AMFOn=0;
int AMFLog=1;

char *isMobileString, *isTabletString, *isTouchString;
char KeyFullBrowser[MAX_SIZE];
char HomeDir[MAX_SIZE];
#pragma mark handler
static int handlerAMF(request_rec* r)
{
    if (AMFOn == 1) {
        char *IsMobile="false";
        char *IsTablet="false";
        char *IsTouch="false";
        char *mOS="nc";
        char *mOSVersion="nc";
        const char *userAgent = NULL;
        const char *x_operamini_phone_ua = NULL;
        const char *x_operamini_ua = NULL;
        const char *x_user_agent = NULL;
        
        
        int n=0;
        if (apr_table_get(r->headers_in, "User-Agent") != NULL) {
            if (r->headers_in != NULL)
            {
                userAgent = apr_table_get(r->headers_in, "User-Agent");
                x_operamini_phone_ua = apr_table_get(r->headers_in, "X-OperaMini-Phone-Ua");
                x_operamini_ua = apr_table_get(r->headers_in, "X-OperaMini-Ua");
                n++;
            }
            // verify for opera mini browser
            char user_agent[strlen(apr_table_get(r->headers_in,"User-Agent"))];
            strcpy(user_agent,apr_table_get(r->headers_in,"User-Agent"));
            if (x_user_agent) {
                strcpy(user_agent,x_user_agent);
            }
            if (x_operamini_phone_ua) {
                strcpy(user_agent,x_operamini_phone_ua);
            }
            int loop=0;
            char ua[strlen(user_agent)];
            for(loop=0;loop<strlen(user_agent);loop++)
                ua[loop]=tolower(user_agent[loop]);
            //ap_log_error(APLOG_MARK, APLOG_ERR, 0, NULL, "ua: %s", string);
            if (checkIsMobile(ua)==1) {
                IsMobile="true";
                if (checkIsTablet(ua)==1) {
                    IsTablet="true";
                }
                if (checkIsTouch(ua)==1) {
                    IsTouch="true";
                }
                mOS=getOperativeSystem(ua);
                mOSVersion=getOperativeSystemVersion(ua,mOS);
            }
         
        }
        apr_table_t *e = r->subprocess_env;
        apr_table_setn(e, "AMF_ID", "mod_amf_detection");
        apr_table_setn(e, "AMF_DEVICE_IS_MOBILE", IsMobile);
        apr_table_setn(e, "AMF_DEVICE_IS_TABLET", IsTablet);
        apr_table_setn(e, "AMF_DEVICE_IS_TOUCH", IsTouch);
        apr_table_setn(e, "AMF_DEVICE_MOBILE_OS", mOS);
        apr_table_setn(e, "AMF_DEVICE_MOBILE_OS_VERSION", mOSVersion);
        apr_table_setn(e, "AMF_VER",AMF_VERSION);
        if (setFullBrowser==1) {
            if (r->args) {
                if (checkQueryStringIsFull (r->args)==1) {
                    apr_table_add(r->headers_out, "Set-Cookie","amfFull=true; path=/;");
                    apr_table_add(e, "AMF_FORCE_TO_DESKTOP", "true");
                }
            }
            if (get_cookie_param(r)==1) {
                apr_table_add(e, "AMF_FORCE_TO_DESKTOP", "true");
            }
        }
        apr_table_setn(e, "AMF_VER", AMF_VERSION);
        apr_table_set(r->headers_out, "AMFplus-Ver", AMF_VERSION);
    }
    return DECLINED;
}
/* Compile the regular expression described by "regex_text" into
 "r". */
#pragma mark function
int compile_regex (regex_t * r, const char * regex_text)
{
    int status = regcomp (r, regex_text, REG_EXTENDED|REG_NEWLINE);
    if (status != 0) {
        char error_message[MAX_ERROR_MSG];
        regerror (status, r, error_message, MAX_ERROR_MSG);
        printf ("Regex error compiling '%s': %s\n",
                regex_text, error_message);
        return 1;
    }
    return 0;
}

/*
 Match the string in "to_match" against the compiled regular
 expression in "r".
 */

int match_regex (regex_t * r, const char * to_match)
{
    /* "P" is a pointer into the string which points to the end of the
     previous match. */
    const char * p = to_match;
    /* "N_matches" is the maximum number of matches allowed. */
    const int n_matches = 144   ;
    /* "M" contains the matches found. */
    regmatch_t m[n_matches];
    int nomatch = regexec (r, p, n_matches, m, 0);
    if (nomatch) {
        //printf ("No more matches.\n");
        return 1;
    } else {
        return 0;
    }
    return 0;
}
char *match_regex_string (regex_t * r, const char * to_match, int matchOS)
{
    char returnValue[MAX_SIZE];
    const char * p = to_match;
    /* "N_matches" is the maximum number of matches allowed. */
    const int n_matches = 10;
    /* "M" contains the matches found. */
    regmatch_t m[n_matches];
    while (1) {
        int i = 0;
        int nomatch = regexec (r, p, n_matches, m, 0);
        if (nomatch) {
            return "nc";
        }
        for (i = 0; i < n_matches; i++) {
            int start;
            int finish;
            if (m[i].rm_so == -1) {
                break;
            }
            start = m[i].rm_so + (p - to_match);
            finish = m[i].rm_eo + (p - to_match);
            if (i == matchOS) {
                sprintf(returnValue, "%.*s", (finish - start), to_match + start);
                size_t size=strlen(returnValue) + 1;
                return strndup(returnValue, size);
            }
        }
        p += m[0].rm_eo;
    }
    sprintf(returnValue, "nc");
    size_t size=strlen(returnValue) + 1;
    return strndup(returnValue, size);
}

/* INTERNET CONNECTION */
int socket_connect(char *host, in_port_t port){
    struct hostent *hp;
    struct sockaddr_in addr;
    int on = 1, sock;
    
    if((hp = gethostbyname(host)) == NULL){
        herror("AMF error:");
        exit(1);
    } else {
        bcopy(hp->h_addr, &addr.sin_addr, hp->h_length);
        
        addr.sin_port = htons(port);
        addr.sin_family = AF_INET;
        sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
        setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, (const char *)&on, sizeof(int));
        if(sock == -1){
            perror("setsockopt");
            exit(1);
        } else {
            if(connect(sock, (struct sockaddr *)&addr, sizeof(struct sockaddr_in)) == -1){
                perror("connect");
                exit(1);
            }
        }
    }
    return sock;
}
int get_cookie_param(request_rec *r)
{
    const char *cookies;
    const char *start_cookie;
    int returnValue=0;
    
    if ((cookies = apr_table_get(r->headers_in, "Cookie"))) {
        char cookiesCompare[strlen(cookies)];
        strcpy(cookiesCompare,cookies);
        if (compare("amfFull=true",cookiesCompare)==1) {
            returnValue=1;
        }
        
    }
    return returnValue;
}

int checkQueryStringIsFull (char *queryString) {
    int returnValue=0;
    if (compare("desktop=true",queryString)==1) {
        returnValue=1;
    }
    return returnValue;
}
int checkIsMobile (char *userAgent) {
    int returnValue=0;
    char * pch;
    char * stringApp=NULL;
    char * copy = malloc(strlen(isMobileString) + 1);
    strcpy(copy, isMobileString);
    pch = strtok (copy,",");
    int count=0;
    while (pch != NULL)
    {
        regex_t r;
        if (compile_regex(& r, pch)==0) {
            if (match_regex(& r, userAgent)==0) {
                regfree (& r);
                free(copy);
                free(pch);
                return 1;
            }
        }
        regfree (& r);
        pch = strtok (NULL, ",");
    }
    free(copy);
    free(pch);
    
    return returnValue;
}
int checkIsTouch (char *userAgent) {
    int returnValue=0;
    char * pch;
    char * copy = malloc(strlen(isTouchString) + 1);
    strcpy(copy, isTouchString);
    pch = strtok (copy,",");
    while (pch != NULL)
    {
        regex_t r;
        if (compile_regex(& r, pch)==0) {
            if (match_regex(& r, userAgent)==0) {
                regfree (& r);
                free(copy);
                free(pch);
                return 1;
            }
        }
        regfree (& r);
        pch = strtok (NULL, ",");
    }
    free(copy);
    free(pch);
    return returnValue;
}

int checkIsTablet (char *userAgent) {
    int returnValue=0;
    char * pch;
    char * copy = malloc(strlen(isTabletString) + 1);
    strcpy(copy, isTabletString);
    pch = strtok (copy,",");
    
    while (pch != NULL)
    {
        regex_t r;
        if (compile_regex(& r, pch)==0) {
            if (match_regex(& r, userAgent)==0) {
                regfree (& r);
                free(copy);
                free(pch);
                return 1;
            }
        }
        regfree (& r);
        pch = strtok (NULL, ",");
    }
    free(copy);
    free(pch);
    return returnValue;
}
int compare (char *stringToSearch, char *userAgentSearch) {
    
    int returnValue=0;
    char *stringCompare;
    char *firstChar=substring(stringToSearch, 0,1);
    char *stringCompareFirst=strstr(firstChar,"^");
    if (stringCompareFirst !=NULL) {
        if (strlen(stringToSearch) - 1 <= strlen(userAgentSearch)) {
            char *stringToSearchSub=substring(stringToSearch, 1,strlen(stringToSearch) - 1);
            char *userAgentCompare=substring(userAgentSearch, 0,strlen(stringToSearchSub));
            char *firstCompareStartWith=strstr(stringToSearchSub,userAgentCompare);
            if (firstCompareStartWith != NULL) {
                returnValue=1;
            }
        }
    } else {
        stringCompare=strstr(userAgentSearch,stringToSearch);
        if(stringCompare != NULL) {
            returnValue=1;
        }
    }
    return returnValue;
}
#pragma mark get mobile OS
char* getOperativeSystemVersion (char *useragent, char *os) {
    char returnValue[MAX_SIZE];
    char pch[MAX_SIZE];
    int matchOS=0;
    if (strcmp("android", os)==0) {
        sprintf(pch,"android ([0-9]\\.[0-9](\\.[0-9])?)");
        matchOS=1;
    } else if (strcmp("ios", os)==0) {
        sprintf(pch," os ([0-9]\\_[0-9](\\_[0-9])?)");
        matchOS=1;
    } else if (strcmp("windows phone", os)==0) {
        sprintf(pch,"( phone| phone os) ([0-9]\\.[0-9](\\.[0-9])?)");
        matchOS=2;
    } else if (strcmp("symbian", os)==0) {
        sprintf(pch,"symbianos/([0-9]\\.[0-9](\\.[0-9])?)");
        matchOS=1;
    }
    
    if (matchOS!=0) {
        regex_t r;
        if (compile_regex(& r, pch)==0) {
            char *returnMatch=match_regex_string(& r, useragent,matchOS);
            strcpy(returnValue,returnMatch);
            size_t size=strlen(returnValue) + 1;
            return strndup(returnValue, size);
        }
        regfree (& r);
        free(pch);
    }
    sprintf(returnValue, "nc");
    size_t size=strlen(returnValue) + 1;
    return strndup(returnValue, size);
}
char* getOperativeSystem (char *useragent) {
    //Android ([0-9]\.[0-9](\.[0-9])?)
    char returnValue[MAX_SIZE];
    char ostypes[MAX_SIZE]="android,iphone|ipad|ipod,windows phone,symbianos,blackberry,kindle";
    char *pch;
    int osNumber=0;
    pch = strtok (ostypes,",");
    while (pch != NULL)
    {
        regex_t r;
        if (compile_regex(& r, pch)==0) {
            if (match_regex(& r, useragent)==0) {
                if (osNumber==0)
                    sprintf(returnValue, "android");
                else if (osNumber==1)
                    sprintf(returnValue, "ios");
                else if (osNumber==2)
                    sprintf(returnValue, "windows phone");
                else if (osNumber==3)
                    sprintf(returnValue, "symbian");
                else if (osNumber==4)
                    sprintf(returnValue, "blackberry");
                else if (osNumber==5)
                    sprintf(returnValue, "kindle");
                size_t size=strlen(returnValue) + 1;
                return strndup(returnValue, size);
            }
        }
        osNumber++;
        regfree (& r);
        pch = strtok (NULL, ",");
    }
    sprintf(returnValue, "nc");
    size_t size=strlen(returnValue) + 1;
    return strndup(returnValue, size);
}
char* readFile(char *nameFile, char *type) {
    FILE *fp;
    char * line = NULL;
    size_t len = 0;
    ssize_t read;
    fp = fopen(nameFile, "r");
    if (fp == NULL) {
        if (AMFLog==1)
            printf("I couldn't open %s for writing.\n",nameFile );
        exit(1);
    }
    char dummy[MAX_SIZE];
    while((read = getline(&line, &len, fp)) != -1) {
        sprintf(dummy,"%s", line);
    }
    size_t size=strlen(dummy) + 1;
    if (AMFLog==1)
        printf("Configuration for %s device loaded correctly\n",type);
    return strndup(dummy, size);
}



size_t write_data(void *ptr, size_t size, size_t nmemb, FILE *stream) {
    size_t written;
    written = fwrite(ptr, size, nmemb, stream);
    return written;
}
char* substring(const char* str, size_t begin, size_t len)
{
    if (str == 0 || strlen(str) == 0 || strlen(str) < begin || strlen(str) < (begin+len))
        return 0;
    
    return strndup(str + begin, len);
}

/* DIRECTIVE HTTPD.CONF */

static const char *set_fullDesktop(cmd_parms *parms, void *dummy, int flag)
{
    int size=0;
    size=strlen(HomeDir);
    if (size==0) {
        perror("AMFHome is not setted");
        exit(1);
    }
    setFullBrowser=flag;
    if (AMFLog==1)
        printf ("AMFFullBrowser is correctly setted\n");
    return NULL;
}
static const char *set_activate(cmd_parms *parms, void *dummy, int flag)
{
    int size=0;
    size=strlen(HomeDir);
    if (size==0) {
        perror("AMFHome is not setted");
        exit(1);
    }
    AMFOn=flag;
    if (AMFOn==1) {
        if (AMFLog==1)
            printf ("AMF is on\n");
    } else {
        if (AMFLog==1)
            printf ("AMF is off\n");
    }
    return NULL;
}
static const char *set_amflog(cmd_parms *parms, void *dummy, int flag)
{
    AMFLog=flag;
    return NULL;
}

static const char *set_fullBrowserKey(cmd_parms *cmd, void *dummy, const char *map)
{
    int size=0;
    size=strlen(HomeDir);
    if (size==0) {
        perror("AMFHome is not setted");
        exit(1);
    }
    sprintf(KeyFullBrowser,"%s",map);
    
    if (AMFLog==1)
        printf ("AMFKeyFullBrowser is %s \nFor access the device to fullbrowser set the link: <url>%s=true\n",KeyFullBrowser,KeyFullBrowser);
    return NULL;
}
static const char *set_downloadParam(cmd_parms *parms, void *dummy, int flag)
{
    int size=0;
    size=strlen(HomeDir);
    if (size==0) {
        perror("AMFHome is not setted");
        exit(1);
    }
    setDownloadParam=flag;
    if (AMFLog==1)
        printf ("AMFDownloadParam is correctly setted\n");
    char nameFile[MAX_SIZE];
    sprintf(nameFile,"%s/litemobiledetection.config",HomeDir);
    if (setDownloadParam==1) {
        isMobileString=downloadFile(ISMOBILE_URL,nameFile);
        if (isMobileString != NULL) {
            if (AMFLog==1)
                printf("Configuration for mobile device detection downloaded and saved correctly\n");
        } else {
            if (AMFLog==1)
                printf("Configuration for mobile device detection downloaded failed, try to take old configuration\n");
            isMobileString=readFile(nameFile,"mobile");
        }
    } else {
        printf("AMFDownloadParam is Off try to load local configuration file\n");
        isMobileString=readFile(nameFile,"mobile");
    }
    // Detect tablet devices
    sprintf(nameFile,"%s/litetabletdetection.config",HomeDir);
    if (setDownloadParam==1) {
        isTabletString=downloadFile(ISTABLET_URL,nameFile);
        if (isTabletString != NULL) {
            if (AMFLog==1)
                printf("Configuration for tablet device detection downloaded and saved correctly\n");
        } else {
            if (AMFLog==1)
                printf("Configuration for tablet device detection downloaded failed, try to take old configuration\n");
            isTabletString=readFile(nameFile,"tablet");
        }
    } else {
        isTabletString=readFile(nameFile,"tablet");
    }
    
    // Detect touch
    sprintf(nameFile,"%s/litetouchdetection.config",HomeDir);
    if (setDownloadParam==1) {
        isTouchString=downloadFile(ISTOUCH_URL,nameFile);
        if (isTouchString != NULL) {
            if (AMFLog==1)
                printf("Configuration for touch  device detection downloaded and saved correctly\n");
        } else {
            if (AMFLog==1)
                printf("Configuration for touch device detection downloaded failed, try to take old configuration\n");
            isTouchString=readFile(nameFile,"touch");
        }
    } else {
        isTouchString=readFile(nameFile,"touch");
    }
    return NULL;
}

static const char *set_homeDir(cmd_parms *cmd, void *dummy, const char *map)
{
    if (AMFLog==1) {
        printf("*************************************************\n");
        printf("*     APACHE MOBILE FILTER + VERSION %s      *\n",AMF_VERSION);
        printf("*************************************************\n");
        printf ("AMFHome is correctly setted as: %s\n",map);
    }
    sprintf(HomeDir,"%s",map);
    // Detect mobile
    return NULL;
}


char *downloadFile (char *URI, char fileName[]) {
    int fd;
    FILE *fp;
    char buffer[BUFFER_SIZE];
    char *address;
    char dummy[MAX_SIZE]="";
    char *returnValue=NULL;
    fd = socket_connect(AMF_HOST, 80);
    address=URI;
    if (fd != -1) {
        write(fd, address, strlen(address));
        
        bzero(buffer, BUFFER_SIZE);
        while(read(fd, buffer, BUFFER_SIZE - 1) != 0){
            strcat(dummy, buffer);
            bzero(buffer, BUFFER_SIZE);
        }
        shutdown(fd, SHUT_RDWR);
        size_t size=strlen(dummy) + 1;
        returnValue=malloc(size);
        strcpy(returnValue,dummy);
        fp = fopen(fileName, "w");
        if (fp == NULL) {
            exit(1);
        }
        fprintf(fp, "%s",returnValue);
        fclose(fp);
    }
    close(fd);
    return returnValue;
}
static int amf_per_dir(request_rec * r)
{
    
    return handlerAMF(r);
}
static int amf_post_read_request(request_rec * r)
{
    return handlerAMF(r);
}
static void amf_child_init(apr_pool_t * p, server_rec * s)
{
    
}

static int amf_post_config(apr_pool_t * p, apr_pool_t * plog,
                           apr_pool_t * ptemp, server_rec * s)
{
    return OK;
}
/*static void amf_server_init(apr_pool_t * p, server_rec * s)
 {
 
 } */

///////////////////////
static void register_hooks(apr_pool_t *p)
{
    /* make sure we run before mod_rewrite's handler */
    static const char * const aszSucc[] = {"mod_setenvif.c", "mod_rewrite.c", NULL };
    ap_hook_header_parser(amf_per_dir, NULL, aszSucc, APR_HOOK_FIRST);
}
#pragma mark commands directive
static const command_rec amf_cmds [] = {
    AP_INIT_FLAG("AMFActivate", set_activate, NULL,
                 RSRC_CONF, "Define for activate AMF"),
    AP_INIT_FLAG("AMFLog", set_amflog, NULL,
                 RSRC_CONF, "Define for log for AMF"),
    AP_INIT_TAKE1("AMFHome", set_homeDir, NULL,
                  RSRC_CONF, "Define HomeDirectory"),
    AP_INIT_FLAG("AMFFullBrowser", set_fullDesktop, NULL,
                 RSRC_CONF, "Define if you want to manage fullbrowser"),
    AP_INIT_TAKE1("AMFFullBrowserAccessKey", set_fullBrowserKey, NULL,
                  RSRC_CONF, "Define the accesskey for your fullbrowser"),
    AP_INIT_FLAG("AMFDownloadParam", set_downloadParam, NULL,
                 RSRC_CONF, "Define if you want to download param"),
    {NULL}
};

module AP_MODULE_DECLARE_DATA amf_module =
{
    STANDARD20_MODULE_STUFF,
    NULL, /* per-directory config creator */
    NULL,     /* dir config merger */
    NULL,     /* server config creator */
    NULL,     /* server config merger */
    amf_cmds, /* command table */
    register_hooks
};
