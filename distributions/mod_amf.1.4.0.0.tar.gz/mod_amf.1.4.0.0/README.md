# AMFPlus

Welcome to the Apache Mobile Filter + the fastest mobile detection
for install the apache moduel is very simple:

install apache webserver 2.0.x, 2.2.x, 2.4.x or newer (downloadable from http://httpd.apache.org)

. ./install.sh

apachectl start

that's it all!!!!

Enjoy with AMF+

For more info: http://www.apachemobilefilter.org

Copyrights (c) 2009-2018 apachemobilefilter.org, All Rights Reserved

