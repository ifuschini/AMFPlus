#!/bin/sh
#  Script.sh
#
#
#  Created by Idel Fuschini on 10/02/2014
#  and contributed by Dany Gielow
#
clear
echo "*********************************************"
echo "***   APACHE MOBILE FILTER + INSTALLER    ***"
echo "*********************************************"
var=0;
while [ $var -eq 0 ]
do
    myapxs=`which apxs2 || which apxs`
    echo "Found apxs/apxs2: $myapxs"
    echo "Please give the path to apxs/apxs2 [$myapxs]: \c"
    read apxs
    if [ -z $apxs ]; then
        apxs=$myapxs
    fi
    if [ -f $apxs ]; then
        echo "file exists"
        sudo $apxs -c -a -i mod_amf.c
        var=1
        else
        echo "File does not exist $apxs\n\nPlease try again !!!!!!\n"
        var=0
    fi
done
